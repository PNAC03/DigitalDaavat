
import UIKit

class LoginController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBOutlet weak var EmailField: UITextField!
    @IBOutlet weak var PassField: UITextField!
    
    struct logindetail{
        static var sessionobj:UsrController?
        static var state: Int = -1
    }
    
    @IBAction func sessionbtn(_ sender: Any) {
        //database connection and mapping (verify function)
        let usrsession: UsrController? = UsrController()
        logindetail.sessionobj = usrsession
        logindetail.state = 1
        performSegue(withIdentifier: "loggedin", sender: nil)
    }
    
    @IBOutlet weak var loginbtn: UIButton!
    @IBOutlet weak var validatecredbtn: UIButton!
    
    @IBAction func validatecred(_ sender: Any) {
        if let x = EmailField.text, x.isEmpty{
            warn()
        }
        else{
            validatecredbtn.isHidden = true
        }
    }
   
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    @IBOutlet weak var warnlabel: UILabel!
    @IBOutlet weak var warnimg: UIImageView!
    func warn(){
         print("going through")
        let okHandler = {
            (action: UIAlertAction) -> Void in
            self.warnimg.isHidden = false
            self.warnlabel.isHidden = false
            self.warnlabel.text = "Credentials Invalid"
        }
        let alrt = UIAlertController(title: "Info", message: "Credentials Invalid", preferredStyle: UIAlertController.Style.alert)
        alrt.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: okHandler))
        present(alrt, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "loggedin"{
            let destObj = segue.destination as! MainPage
            destObj.comingfrom = 1
        }
    }
}
