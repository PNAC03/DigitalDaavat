import UIKit

class ProfilePageController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        SwitchOutlet.onTintColor = UIColor.init(displayP3Red: 1, green: 0.42, blue: 0.34, alpha: 1)
        defaultmode()
    }
    
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var ContactField: UITextField!
    @IBOutlet weak var EmailField: UITextField!
    @IBOutlet weak var GenderField: UITextField!
    @IBOutlet weak var PassField: UITextField!
    @IBOutlet weak var SwitchOutlet: UISwitch!
    @IBOutlet weak var BackgOutlet: UIImageView!
    @IBOutlet weak var ProfileBtn: UIButton!
    @IBOutlet weak var HomeBtn: UIButton!
    @IBOutlet weak var OrdersBtn: UIButton!
    @IBOutlet weak var lock: UIImageView!
    @IBOutlet weak var lock2: UIImageView!
    @IBOutlet weak var lock3: UIImageView!
    @IBOutlet weak var lock4: UIImageView!
    
    
    @available(iOS 13.0, *)
    @IBAction func SwitchAction(_ sender: Any) {
        if(SwitchOutlet.isOn == true)
        {
            //UI Configs
            lock2.isHidden = true
            ContactField.isUserInteractionEnabled = true
            ContactField.backgroundColor = UIColor.init(red: 1.0, green: 0.25, blue: 0.33, alpha: 0.12)
            lock3.isHidden = true
            EmailField.isUserInteractionEnabled = true
            EmailField.backgroundColor = UIColor.init(red: 1.0, green: 0.25, blue: 0.33, alpha: 0.12)
            lock4.isHidden = true
            PassField.isUserInteractionEnabled = true
            PassField.backgroundColor = UIColor.init(red: 1.0, green: 0.25, blue: 0.33, alpha: 0.12)
            
        }
        else {
            if(SignUpController.sessiondetail.state == 1){
                SignUpController.sessiondetail.sessionobj?.setPhone(var1: Int(ContactField.text!)!)
                SignUpController.sessiondetail.sessionobj?.setEmail(var1: EmailField.text!)
                SignUpController.sessiondetail.sessionobj?.setPass(var1: PassField.text!)
            lock.isHidden = false
            NameField.isUserInteractionEnabled = false
            NameField.backgroundColor = UIColor.systemGray4
            lock2.isHidden = false
            ContactField.isUserInteractionEnabled = false
            ContactField.backgroundColor = UIColor.systemGray4
            lock3.isHidden = false
            EmailField.isUserInteractionEnabled = false
            EmailField.backgroundColor = UIColor.systemGray4
            lock4.isHidden = false
            PassField.isUserInteractionEnabled = false
            PassField.backgroundColor = UIColor.systemGray4
            //Edit Logic when button turned off
            //logic to update SQL DB (Cloud Implementation)
            }
            //else if() login state & session detail
        }
    }
    
    func defaultmode(){
        if(SignUpController.sessiondetail.state == 1){
            NameField.text = SignUpController.sessiondetail.sessionobj?.getName()
            let temp: Int? = SignUpController.sessiondetail.sessionobj?.getPhone()
            ContactField.text = String(temp!)
            EmailField.text = SignUpController.sessiondetail.sessionobj?.getEmail()
            PassField.text = SignUpController.sessiondetail.sessionobj?.getPass()
            GenderField.text = SignUpController.sessiondetail.sessionobj?.getGen()
        }
        //else if{
            //Login Controller session detail state
        //}
    }
    
    @IBAction func SignOut(_ sender: Any) {
        //destroy session
        if(SignUpController.sessiondetail.state == 1){
            SignUpController.sessiondetail.sessionobj = nil
            SignUpController.sessiondetail.state = 0}
        else if (LoginController.logindetail.state == 1){
            LoginController.logindetail.sessionobj = nil
            LoginController.logindetail.state = 0
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

}
