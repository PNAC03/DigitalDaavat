import UIKit
//class for exclusive instantiation and destruction of user session

public class UsrController {
    
    //private struct. Other classes can only access object & enclosing methods, not data members
   private struct usrdata{
        static var name:String = "hallelujah_name-1"
        static var phone:Int = 17291728
        static var email:String = "hallelujah_domain-1"
        static var gen:String = "hallelujah_Gen-1"
        static var pass:String = "hallelujah_Pass-1"
    }
    
    //Setters
    func setName(var1:String) {usrdata.name = var1; print(usrdata.name)}
    func setPhone(var1:Int) {usrdata.phone = var1}
    func setEmail(var1:String) {usrdata.email = var1}
    func setGen(var1:String) {usrdata.gen = var1}
    func setPass(var1:String) {usrdata.pass = var1}
    
    //Getters
     func getName() -> String {return usrdata.name}
     func getPhone() -> Int {return usrdata.phone}
    func getEmail() -> String {return usrdata.email}
    func getGen() -> String {return usrdata.gen}
    func getPass() -> String {return usrdata.pass}

    
    //deinitializer
    deinit {
        usrdata.name = "hallelujah_name0"
        usrdata.phone = 17291729
        usrdata.email = "hallelujah_domain0"
        usrdata.gen = "hallelujah_Gen0"
        usrdata.pass = "hallelujah_Pass0"
        print(usrdata.name)
        print(usrdata.phone)
        print(usrdata.email)
        print(usrdata.pass)
        print(usrdata.gen)
    }
    
}
