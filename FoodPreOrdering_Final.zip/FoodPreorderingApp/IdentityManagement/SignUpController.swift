import UIKit
//import PerfectMySQL
//import PerfectCRUD
import MySQLDriver

class SignUpController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        GenderSegBtn.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: UIControl.State.selected)
        let usrsession: UsrController? = UsrController()
        sessiondetail.sessionobj = usrsession
    }
    
    @IBOutlet weak var NameField: UITextField!
    @IBOutlet weak var ContactField: UITextField!
    @IBOutlet weak var EmailField: UITextField!
    @IBOutlet weak var NewPassField: UITextField!
    @IBOutlet weak var GenderSegBtn: UISegmentedControl!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    struct sessiondetail{
        static var sessionobj:UsrController?
        static var state:Int = -1
        // state -1 if fresh install
        // state 1 if signed in
        // state 0 if signed out after a sign in
    }
    
    @IBOutlet weak var validatebtn: UIButton!
    @IBAction func validatefunc(_ sender: Any) { // input validation
        if let x = ContactField.text, x.isEmpty{
            warn()
        }
        else {
            validatebtn.isHidden = true
            warnimg.isHidden = true
            warnlabel.isHidden = true
        }
        
    }
    //assign values to static struct
    @IBAction func signupprocess(_ sender: Any) {
        print("inside")
        // set data upon consent & session instantiation
        setdata()
        
        performSegue(withIdentifier: "signedup", sender: nil)
        //functgion to upload details to database
//        upload()
    }
    
    
    func setdata(){
        //debugname
        
        sessiondetail.sessionobj?.setName(var1:NameField.text!)
        sessiondetail.sessionobj?.setPhone(var1:Int(ContactField.text!)!)
        sessiondetail.sessionobj?.setEmail(var1: EmailField.text!)
        sessiondetail.sessionobj?.setPass(var1: NewPassField.text!)
        if(GenderSegBtn.selectedSegmentIndex == 0)        {sessiondetail.sessionobj?.setGen(var1: "Male")}
        else if(GenderSegBtn.selectedSegmentIndex == 1) {sessiondetail.sessionobj?.setGen(var1: "Female")}
        sessiondetail.state = 1 // Flag indicating STATUS
    }

    
    @IBOutlet weak var warnlabel: UILabel!
    @IBOutlet weak var warnimg: UIImageView!
    
    func warn(){
         print("going through")
        let okHandler = {
            (action: UIAlertAction) -> Void in
            self.warnimg.isHidden = false
            self.warnlabel.isHidden = false
            self.warnlabel.text = "Please Enter all Details Carefully"
        }
        let alrt = UIAlertController(title: "Info", message: "Invalid Inputs", preferredStyle: UIAlertController.Style.alert)
        alrt.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: okHandler))
        present(alrt, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "signedup"{
            let destObj = segue.destination as! MainPage
//            destObj.strName = (NameField.text)!
        }
    }
    
    //trying mysqlnativedriver
    func upload(){
        let con = MySQL.Connection()
        let db_name = "DD2"

        do{
            // open a new connection
            try con.open("0.0.0.0", user: "root", passwd: "Asdf34567")

            // create a new database for tests, use exec since we don't expect any results
            try con.exec("DROP DATABASE IF EXISTS " + db_name)
            print("Dropped Table!")
//            try con.exec("CREATE DATABASE IF NOT EXISTS " + db_name)
//
//            // create a table for our tests
//            try con.exec("CREATE TABLE users (                 Name VARCHAR(255), Phone INT, Email VARCHAR(255), Gender VARCHAR(255), Password VARCHAR(255));")
//            print("Created Table!")
            // select the database
//            try con.use(db_name)
            try con.close()
        }
        catch (let e) {
            print(e)
        }
    }
    
    //trying mySQLKit - vaibhav's suggestion
//    func sqlconnect(){
//        let testHost = "127.0.0.1"
//        let testUser = "root"
//        let testPassword = "Asdf34567"
//        let testDB = "DD"
//
//        let mysql = MySQL() // Create an instance of MySQL to work with
//
//    let connected = mysql.connect(host: testHost, user: testUser, password: testPassword)
//
//    guard connected else {
//        // verify we connected successfully
//        print(mysql.errorMessage())
//        return
//    }
//
//    defer {
//        mysql.close() //This defer block makes sure we terminate the connection once finished, regardless of the result
//    }

//    Choose the database to work with
//    guard mysql.selectDatabase(named: testDB) else {
//        Log.info(message: "Failure: \(mysql.errorCode()) \(dataMysql.errorMessage())")
//            return
//    }
    }

    

