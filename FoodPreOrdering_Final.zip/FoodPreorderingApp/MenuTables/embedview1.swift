//
//  embedview1.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 31/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit


class embedview1: UIViewController {
    
    @IBOutlet weak var fdf: UIView!
    override func viewDidLoad(){
    super.viewDidLoad()
        self.fdf.cornerRadius(usingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 20, height: 20))
    }
}
