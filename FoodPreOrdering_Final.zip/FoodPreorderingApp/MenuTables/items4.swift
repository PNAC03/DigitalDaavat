//
//  items4.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 01/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class items4: UITableViewController {

    override func viewDidLoad(){
        super.viewDidLoad()
        createProductArray()
        tableView.register(ProductCell.self, forCellReuseIdentifier: cellid)
        
    }
    
    let cellid = "food_item"
    var products : [Product] = [Product]() //product structure
    
     override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellid, for: indexPath) as! ProductCell
        let currentLastItem = products[indexPath.row]
        cell.product = currentLastItem
        return cell
     }
    
    func createProductArray(){
        products.append(Product(productName: "Lassi", productImage: #imageLiteral(resourceName: "shakes2"), productDesc: "Amritsari Special"))
        print("afteraddline1")
        products.append(Product(productName: "Vanilla Z", productImage: #imageLiteral(resourceName: "shakes1"), productDesc: "Sugar Sweet"))
        products.append(Product(productName: "Red Mojito", productImage: #imageLiteral(resourceName: "shakes5"), productDesc: "Berry Mojito"))
        products.append(Product(productName: "Strawberry on Ice", productImage: #imageLiteral(resourceName: "shakes3"), productDesc: "Berry Shake"))
        products.append(Product(productName: "Lemonade", productImage: #imageLiteral(resourceName: "shakes4"), productDesc: "Diljit's Chill"))
    }
    
     override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    
}
