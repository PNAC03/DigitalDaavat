//
//  items5.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 01/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class items5: UITableViewController {

    override func viewDidLoad(){
        super.viewDidLoad()
        createProductArray()
        tableView.register(ProductCell.self, forCellReuseIdentifier: cellid)
        
    }
    
    let cellid = "food_item"
    var products : [Product] = [Product]() //product structure
    
     override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellid, for: indexPath) as! ProductCell
        let currentLastItem = products[indexPath.row]
        cell.product = currentLastItem
        return cell
     }
    
    func createProductArray(){
        products.append(Product(productName: "DaClassic", productImage: #imageLiteral(resourceName: "no5.png"), productDesc: "The Subway Style"))
        print("afteraddline1")
        products.append(Product(productName: "MasalaSpl", productImage: #imageLiteral(resourceName: "noodles"), productDesc: "Masala and Green"))
        products.append(Product(productName: "Cheesieee", productImage: #imageLiteral(resourceName: "no4.png"), productDesc: "Cheese Spl"))
        products.append(Product(productName: "Schezwan", productImage: #imageLiteral(resourceName: "no2.png"), productDesc: "Authentic one"))
    }
    
     override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    
}
