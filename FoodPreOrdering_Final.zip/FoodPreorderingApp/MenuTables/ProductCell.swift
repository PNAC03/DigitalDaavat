//
//  ProductCell.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 30/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

protocol ProductCellDelegate {
    func increaseNumber(cell: ProductCell, number:Int)
    func decreaseNumber(cell: ProductCell, number:Int)
}

class ProductCell: UITableViewCell{
    var delegate : ProductCellDelegate?
    let minValue = 0
    
    var product: Product? {
        didSet {
            productImage.image = product?.productImage
            productNameLabel.text = product?.productName
            productDescriptionLabel.text = product?.productDesc
            print("Settong")
        }
    }
    
    private let productNameLabel : UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.boldSystemFont(ofSize: 16)
        lbl.textAlignment = .left
        return lbl
    }()
    
    private let productDescriptionLabel: UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.systemFont(ofSize: 16)
        lbl.textAlignment = .left
        lbl.numberOfLines = 0
        return lbl
    }()
    
    private let decreaseButton : UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(#imageLiteral(resourceName: "image 2"), for:.normal)
        btn.imageView?.contentMode = .scaleAspectFit
        return btn
    }()
    
    private let increaseButton : UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(#imageLiteral(resourceName: "image 1"),for:.normal)
        btn.imageView?.contentMode = .scaleAspectFit
        return btn
    }()
    
    var productQuantity :UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        label.text = "0"
        label.textColor = .black
        return label
    }()
    
    private let productImage : UIImageView = {
        let imgView = UIImageView(image: #imageLiteral(resourceName: "fried rice"))
        imgView.contentMode = .scaleAspectFit
        imgView.clipsToBounds = true
        return imgView
    }()
    
    
    @objc func decreaseFunc() {
     changeQuantity(by: -1)
     
     }
     
     @objc func increaseFunc() {
     changeQuantity(by: 1)
     }
     
     
     func changeQuantity(by amount: Int) {
     var quality = Int(productQuantity.text!)!
     quality += amount
     if quality < minValue {
     quality = 0
     productQuantity.text = "0"
     } else {
     productQuantity.text = "\(quality)"
     }
     delegate?.decreaseNumber(cell: self, number: quality)
     
     }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?){
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.isUserInteractionEnabled = true
        addSubview(decreaseButton)
        addSubview(productQuantity)
        addSubview(increaseButton)
        addSubview(productImage)
        addSubview(productNameLabel)
        addSubview(productDescriptionLabel)
        
        
        
        //CONSTRAINTS
        productImage.anchor(top: topAnchor, left: leftAnchor, bottom: bottomAnchor, right: nil, paddingTop: 5, paddingLeft: 5, paddingBottom: 5, paddingRight: 0, width: 90, height: 0, enableInsets: false)
         productNameLabel.anchor(top: topAnchor, left: productImage.rightAnchor, bottom: nil, right: nil, paddingTop: 20, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 3, height: 0, enableInsets: false)
         productDescriptionLabel.anchor(top: productNameLabel.bottomAnchor, left: productImage.rightAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 3, height: 0, enableInsets: false)
         
        
        let stackView = UIStackView(arrangedSubviews: [decreaseButton, productQuantity,increaseButton])
        stackView.distribution = .equalSpacing
        stackView.axis = .horizontal
        stackView.spacing = 5
        addSubview(stackView)
        //CONSTRAINTS
        stackView.anchor(top: topAnchor, left: productNameLabel.rightAnchor, bottom: bottomAnchor, right: rightAnchor, paddingTop: 15, paddingLeft: 5, paddingBottom: 15, paddingRight: 10, width: 0, height:70, enableInsets: false)
        
        
        increaseButton.addTarget(self, action: #selector(increaseFunc), for: .touchUpInside)
            decreaseButton.addTarget(self, action: #selector(decreaseFunc), for: .touchUpInside)
    }
    
   
    
    
    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
        super.init(coder: aDecoder)
    }
}
