//
//  Product.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 29/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

//global Product Structure
struct Product {
    var productName: String
    var productImage: UIImage
    var productDesc: String
}
