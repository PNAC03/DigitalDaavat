//
//  embedview4.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 01/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class embedview4: UIViewController {

    @IBOutlet weak var shakesview: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.shakesview.cornerRadius(usingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 20, height: 20))

    }
    


}
