//
//  embedview5.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 01/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class embedview5: UIViewController {

    
    
    @IBOutlet weak var noodlesView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.noodlesView.cornerRadius(usingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 20, height: 20))
        // Do any additional setup after loading the view.
    }
    

  

}
