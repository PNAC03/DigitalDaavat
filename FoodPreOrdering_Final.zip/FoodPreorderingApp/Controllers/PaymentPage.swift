//
//  PaymentPage.swift
//  FoodPreorderingApp
//
//  Created by Aditya 
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class PaymentPage: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    @IBOutlet weak var paymenttype: UISegmentedControl!
    @IBOutlet weak var cardtypeseg: UISegmentedControl!
    @IBOutlet weak var cardnumlbl: UILabel!
    @IBOutlet weak var cardnumfield: UITextField!
    @IBOutlet weak var expirylbl: UILabel!
    @IBOutlet weak var mmlbl: UITextField!
    @IBOutlet weak var yylbl: UITextField!
    @IBOutlet weak var cvvlbl: UILabel!
    @IBOutlet weak var cvvfield: UITextField!
    @IBOutlet weak var slashlbl: UILabel!
    @IBOutlet weak var vpafield: UITextField!
    @IBOutlet weak var vpalbl: UILabel!
    @IBOutlet weak var gpayimg: UIImageView!
    @IBOutlet weak var phonepeimg: UIImageView!
    @IBOutlet weak var paytmimg: UIImageView!
    @IBOutlet weak var visaimg: UIImageView!
    @IBOutlet weak var mastercardimg: UIImageView!
    
    
    @IBAction func placeorder(_ sender: Any) {
        
    }
    
    @IBAction func cardtypebtn(_ sender: Any) {
        var selection:Int = paymenttype.selectedSegmentIndex
        switch(selection){ 
        case 0:
            cardnumlbl.isHidden = false
            cardnumfield.isHidden = false
            cardtypeseg.isHidden = false
            expirylbl.isHidden = false
            mmlbl.isHidden = false
            yylbl.isHidden = false
            cvvlbl.isHidden = false
            cvvfield.isHidden = false
            slashlbl.isHidden = false
            visaimg.isHidden = false
            mastercardimg.isHidden = false
            vpafield.isHidden = true
            vpalbl.isHidden = true
            gpayimg.isHidden = true
            phonepeimg.isHidden = true
            paytmimg.isHidden = true
        case 1:
            cardnumlbl.isHidden = true
            cardnumfield.isHidden = true
            cardtypeseg.isHidden = true
            expirylbl.isHidden = true
            mmlbl.isHidden = true
            yylbl.isHidden = true
            cvvlbl.isHidden = true
            cvvfield.isHidden = true
            slashlbl.isHidden = true
            visaimg.isHidden = true
            mastercardimg.isHidden = true
            vpafield.isHidden = false
            vpalbl.isHidden = false
            gpayimg.isHidden = false
            phonepeimg.isHidden = false
            paytmimg.isHidden = false
        default:
            cardnumlbl.isHidden = false
            cardnumfield.isHidden = false
            cardtypeseg.isHidden = false
            expirylbl.isHidden = false
            mmlbl.isHidden = false
            yylbl.isHidden = false
            cvvlbl.isHidden = false
            cvvfield.isHidden = false
            slashlbl.isHidden = false
            visaimg.isHidden = false
            mastercardimg.isHidden = false
            vpafield.isHidden = true
            vpalbl.isHidden = true
            gpayimg.isHidden = true
            phonepeimg.isHidden = true
            paytmimg.isHidden = true
        }
    }
}
