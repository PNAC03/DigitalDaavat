//
//  CartTable.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 01/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class CartTable: UITableViewController {

    var combinedData: [Product] = [Product]()

       override func viewDidLoad() {
           super.viewDidLoad()
        tableView.register(ProductCell.self, forCellReuseIdentifier: "cart_item")
           // Assuming you have created your source table view controllers in the storyboard
           // and set their identifiers to "SourceTableViewController1" and "SourceTableViewController2"
           let source1 = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "sandboard") as! Items1
           let source2 = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "noodlesboard") as! items5
        source1.createProductArray()
        source2.createProductArray()
           // Combine the data from the source table view controllers
           combinedData = source1.products + source2.products
        print(combinedData.count)
           // Reload the table view to display the combined data
           tableView.reloadData()
       }

       override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return combinedData.count
       }

       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cart_item", for: indexPath) as! ProductCell
        let currentLastItem = combinedData[indexPath.row]
        cell.product = currentLastItem
        return cell
       }
    
        
}


