import UIKit

class OrdersController: UIViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    


   
    
    @IBAction func Confirmbt(_ sender: Any) {
        performSegue(withIdentifier: "confirmedorders", sender: nil)
    }
    func warn(){
     print("going through")
        let okHandler = {
            (action: UIAlertAction) -> Void in
            self.performSegue(withIdentifier: "confirmedorders", sender: nil)
        }
    
    let alrt = UIAlertController(title: "Are you Sure?", message: "Invalid Inputs", preferredStyle: UIAlertController.Style.actionSheet)
    alrt.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: okHandler))
    alrt.addAction(UIAlertAction(title: "Not Yet", style: UIAlertAction.Style.destructive, handler: nil))
    present(alrt, animated: true, completion: nil)
    }

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "confirmedorders"{
        _ = segue.destination as! PaymentPage
    }
    
}
}
