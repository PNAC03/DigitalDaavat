import UIKit

class AboutUs: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create a UILabel
        let label = UILabel()
        label.numberOfLines = 16  // Number of lines to display
        label.lineBreakMode = .byTruncatingTail  // Truncate text at the end
        
        // Set the text
        label.text = "Digital Daavat is an exciting startup in the food preordering industry, offering a convenient way to enjoy your favorite meals. With a user-friendly mobile app and website, it connects users to a network of local restaurants, providing a diverse range of cuisines to choose from. Whether you're looking for a quick lunch or a special dinner, Digital Daavat lets you browse menus, customize orders, and schedule deliveries or pickups. Its straightforward payment system and real-time order tracking ensure a hassle-free dining experience, making it a great choice for food enthusiasts seeking convenience and variety."

        // Set the frame and add the label to the view
        label.frame = CGRect(x: 34, y: 185, width: 320, height: 400)
        view.addSubview(label)
    }
}
