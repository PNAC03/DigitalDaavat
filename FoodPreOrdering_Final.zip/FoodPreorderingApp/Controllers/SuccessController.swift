//
//  SuccessController.swift
//  FoodPreorderingApp
//
//  Created by Aditya on 02/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class SuccessController: UIViewController {
    var player:AVAudioPlayer=AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            let audioPath = Bundle.main.path(forResource: "audio", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
        }
        catch{
            //error
        }
        player.play()
        toplayvideo()
        startanimating()
    }
    
    var imagearray: [UIImage] = [ UIImage(named:"e01")!,
                                  UIImage(named:"e02")!,
                                  UIImage(named:"e04")!,
                                  UIImage(named:"e05")!]
    
        var videoPlayer: AVPlayer!
        var videoPlayerController: AVPlayerViewController!
    @IBOutlet weak var videoPreviewLayer: UIView!
    @IBOutlet weak var imgview: UIImageView!
    
    func toplayvideo(){
        guard let path = Bundle.main.path(forResource: "Checkmark", ofType: "mp4") else {
        return }
        let url = NSURL.fileURL(withPath: path)
        videoPlayer = AVPlayer(url: url)
        videoPlayerController = AVPlayerViewController()
        videoPlayerController.player = videoPlayer
        videoPlayerController.view.frame = videoPreviewLayer.frame
        self.addChild(videoPlayerController)
        self.view.addSubview(videoPlayerController.view)
    }
    
    func startanimating(){
        imgview.animationImages = imagearray
        imgview.startAnimating()
    }
}
