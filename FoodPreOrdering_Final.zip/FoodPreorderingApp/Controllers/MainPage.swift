//
//  MainPage.swift
//  FoodPreorderingApp
//
//  Created by Aditya
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class MainPage: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        printlbl()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var NameLbl: UILabel!
    
    var strName: String!
    var comingfrom: Int = 0
    
    func printlbl(){
        if comingfrom == 0 {
            NameLbl.text = "Hi there!" }
        else {
            NameLbl.text = "Welcome back!" }
    }
}
